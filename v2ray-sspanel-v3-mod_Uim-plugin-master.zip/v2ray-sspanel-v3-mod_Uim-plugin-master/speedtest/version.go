package speedtest

const Version = "1.0.0"
